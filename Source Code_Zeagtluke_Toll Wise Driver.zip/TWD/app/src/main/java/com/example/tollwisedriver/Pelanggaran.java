package com.example.tollwisedriver;

public class Pelanggaran {
    String pelanggaran, tanggal;

    public String getPelanggaran() {
        return pelanggaran;
    }

    public String getTanggal() {
        return tanggal;
    }
}
